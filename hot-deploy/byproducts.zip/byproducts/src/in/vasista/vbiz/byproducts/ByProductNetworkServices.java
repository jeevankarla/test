package in.vasista.vbiz.byproducts;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javolution.util.FastMap;
import javolution.util.FastList;

import org.ofbiz.base.conversion.ConversionException;
import org.ofbiz.base.conversion.DateTimeConverters;
import org.ofbiz.base.util.Debug;
import org.ofbiz.base.util.GeneralException;
import org.ofbiz.base.util.UtilDateTime;
import org.ofbiz.base.util.UtilGenerics;
import org.ofbiz.base.util.UtilHttp;
import org.ofbiz.base.util.UtilMisc;
import org.ofbiz.base.util.UtilNumber;
import org.ofbiz.base.util.UtilProperties;
import org.ofbiz.base.util.UtilValidate;
import org.ofbiz.entity.Delegator;
import org.ofbiz.entity.GenericEntity;
import org.ofbiz.entity.GenericEntityException;
import org.ofbiz.entity.GenericValue;
import org.ofbiz.entity.condition.EntityCondition;
import org.ofbiz.entity.condition.EntityFunction;
import org.ofbiz.entity.condition.EntityOperator;
import org.ofbiz.network.NetworkServices;
import org.ofbiz.order.order.OrderChangeHelper;
import org.ofbiz.order.order.OrderServices;
import org.ofbiz.order.shoppingcart.CheckOutHelper;
import org.ofbiz.order.shoppingcart.ShoppingCart;
import org.ofbiz.order.shoppingcart.ShoppingCartEvents;
import org.ofbiz.order.shoppingcart.ShoppingCartItem;
import org.ofbiz.party.party.PartyHelper;
import org.ofbiz.product.price.PriceServices;
import org.ofbiz.security.Security;
import org.ofbiz.service.DispatchContext;
import org.ofbiz.service.GenericServiceException;
import org.ofbiz.service.LocalDispatcher;
import org.ofbiz.service.ModelService;
import org.ofbiz.service.ServiceUtil;
import org.ofbiz.entity.transaction.TransactionUtil;
import org.ofbiz.entity.util.EntityFindOptions;
import org.ofbiz.entity.util.EntityUtil;
import org.ofbiz.entity.GenericPK;
import org.ofbiz.base.util.UtilMisc;

public class ByProductNetworkServices {
	public static final String module = ByProductNetworkServices.class.getName();
	
	 public static List<GenericValue> getByProductProducts(DispatchContext dctx, Map<String, ? extends  Object> context){
    	 Timestamp salesDate = UtilDateTime.nowTimestamp();    	
         Delegator delegator = dctx.getDelegator();
         LocalDispatcher dispatcher = dctx.getDispatcher();
         if(!UtilValidate.isEmpty(context.get("salesDate"))){
        	salesDate =  (Timestamp) context.get("salesDate");  
         }
        Timestamp dayBegin =UtilDateTime.getDayStart(salesDate);
    	List<GenericValue> productList =FastList.newInstance();
    	List condList =FastList.newInstance();
    	condList.add(EntityCondition.makeCondition("productCategoryId", EntityOperator.EQUALS, "MILK_MILKPRODUCTS"));
    	condList.add(EntityCondition.makeCondition(EntityCondition.makeCondition("salesDiscontinuationDate", EntityOperator.EQUALS, null),EntityOperator.OR,
    			 EntityCondition.makeCondition("salesDiscontinuationDate", EntityOperator.GREATER_THAN, dayBegin)));
    	EntityCondition discontinuationDateCondition = EntityCondition.makeCondition(condList, EntityOperator.AND);
    	try{
    		productList =delegator.findList("ProductAndCategoryMember", discontinuationDateCondition,null, null, null, false);
    	}catch (GenericEntityException e) {
			// TODO: handle exception
    		Debug.logError(e, module);
		} 
    	return productList;
	}
	 
	 
	 /*
	  * Helper that returns the product -> productCategory (GenericValue of type ProductAndCategoryMember) map.  Since products can have multiple
	  * categorization schemes, the categoryType id is expected to be passed in (BYPROD_MFG_LOC,
	  * BYPROD_CAT, etc);
	  * 
	  * 
	  */
	 public static Map getProductCategoryMap(Delegator delegator, String categoryId)  {
		 Map productCatMap = FastMap.newInstance();
		 
    	 Timestamp salesDate = UtilDateTime.nowTimestamp();    	
    	 Timestamp dayBegin =UtilDateTime.getDayStart(salesDate);
    	 List<GenericValue> productList =FastList.newInstance();
    	 try{
    		
    		 if (UtilValidate.isNotEmpty(categoryId)) {
    			 List condList =FastList.newInstance();
    			 condList.add(EntityCondition.makeCondition("productCategoryId", EntityOperator.EQUALS, categoryId));
    			 condList.add(EntityCondition.makeCondition(EntityCondition.makeCondition("salesDiscontinuationDate", EntityOperator.EQUALS, null),EntityOperator.OR,
        			 EntityCondition.makeCondition("salesDiscontinuationDate", EntityOperator.GREATER_THAN, dayBegin)));
    			 EntityCondition condition = EntityCondition.makeCondition(condList, EntityOperator.AND);      
    			 productList =delegator.findList("ProductAndCategoryMember", condition,null, null, null, false);
    			 for (int i = 0; i < productList.size(); ++i) {
    				 productCatMap.put(productList.get(i).get("productId"), productList.get(i));
    			 }
    		 }
    	 }catch (GenericEntityException e) {
			// TODO: handle exception
    		Debug.logError(e, module);
    	 } 		 
		 return productCatMap;
	 }
	 public static Map getByProductFacilityCategoryAndClassification(Delegator delegator, Timestamp effectiveDate)  {
		 
		 Map facilityDetail = FastMap.newInstance();
		 if(UtilValidate.isEmpty(effectiveDate)){
			 effectiveDate = UtilDateTime.nowTimestamp();
		 }
		 List<GenericValue> partyClassification = FastList.newInstance();
    	 List<GenericValue> facilityList =FastList.newInstance();
    	 try{
    		 //facilityList = delegator.findList("Facility", EntityCondition.makeCondition("byProdRouteId", EntityOperator.NOT_EQUAL, null), null, null, null, false);
    		 facilityList = delegator.findList("Facility", EntityCondition.makeCondition("facilityTypeId", EntityOperator.EQUALS, "BOOTH"), null, null, null, false);
    		 if (UtilValidate.isNotEmpty(facilityList)) {
    			 for(int i=0;i<facilityList.size();i++){
    				 Map facilityTemp = FastMap.newInstance();
    				 GenericValue facility = facilityList.get(i);
    				 String facilityId = facility.getString("facilityId");
    				 String category = facility.getString("categoryTypeEnum");
    				 String ownerPartyId = facility.getString("ownerPartyId");
    				 if(UtilValidate.isNotEmpty(ownerPartyId)){
    					 List condList =FastList.newInstance();
    	    			 condList.add(EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, ownerPartyId));
    	    			 EntityCondition condition = EntityCondition.makeCondition(condList, EntityOperator.AND);  
    	    			 partyClassification =delegator.findList("PartyClassification", condition,UtilMisc.toSet("partyClassificationGroupId"), null, null, false);
    	    			 partyClassification = EntityUtil.filterByDate(partyClassification, effectiveDate);
    	    			 if(UtilValidate.isNotEmpty(partyClassification)){
    	    				 facilityTemp.put("ownerPartyId", ownerPartyId);
    	    				 facilityTemp.put("categoryTypeEnum", category);
    	    				 String classificationId = EntityUtil.getFirst(partyClassification).getString("partyClassificationGroupId");
    	    				 facilityTemp.put("partyClassification", classificationId);
    	    				 facilityDetail.put(facilityId, facilityTemp);
    	    			 }
    				 }
    			 }
    		 }
    	 }catch (GenericEntityException e) {
    		Debug.logError(e, module);
    		return ServiceUtil.returnError(e.toString());
    	 }
		 return facilityDetail;
	 }
	 
	 public static Map getByProductSales(DispatchContext dctx, Timestamp fromDate, Timestamp thruDate, String salesChannel, String categoryTypeEnum, List productList, List facilityList) {
		 
		 Delegator delegator = dctx.getDelegator();
		 LocalDispatcher dispatcher = dctx.getDispatcher();
		/* List shipmentList = FastList.newInstance();
		 if(UtilValidate.isNotEmpty(salesChannel)){
			 if(salesChannel.equalsIgnoreCase("BYPROD_SALES_CHANNEL")){
				 shipmentList = ByProductNetworkServices.getByProdShipmentIdsByType(delegator, fromDate, thruDate, "BYPRODUCTS");
			 }
			 else{
				 shipmentList = ByProductNetworkServices.getByProdShipmentIdsByType(delegator, fromDate, thruDate, "BYPRODUCTS_PRSALE");
			 }
		 }
		 else{
			 shipmentList = ByProductNetworkServices.getByProdShipmentIds(delegator, fromDate, thruDate);
		 }*/
		 List shipmentList = ByProductNetworkServices.getByProdShipmentIds(delegator, fromDate, thruDate);
		 Map result = FastMap.newInstance();
		 int intervalDays = (UtilDateTime.getIntervalInDays(fromDate, thruDate)+1);
    	 List orderedItems = FastList.newInstance();
    	 List conditionList = FastList.newInstance();
    	 conditionList.add(EntityCondition.makeCondition("orderStatusId", EntityOperator.NOT_IN, UtilMisc.toList("ORDER_CANCELLED","ORDER_REJECTED")));
    	 conditionList.add(EntityCondition.makeCondition("shipmentId", EntityOperator.IN, shipmentList));
    	 if(UtilValidate.isNotEmpty(categoryTypeEnum)){
    		 conditionList.add(EntityCondition.makeCondition("categoryTypeEnum", EntityOperator.EQUALS, categoryTypeEnum));
    	 }
    	 if(UtilValidate.isNotEmpty(productList)){
   			 conditionList.add(EntityCondition.makeCondition(EntityCondition.makeCondition("productId", EntityOperator.IN, productList)));
    	 }
    	 if(UtilValidate.isNotEmpty(facilityList)){
   			 conditionList.add(EntityCondition.makeCondition(EntityCondition.makeCondition("facilityId", EntityOperator.IN, facilityList)));
    	 }
    	 EntityCondition condition = EntityCondition.makeCondition(conditionList,EntityOperator.AND);
    	 try{
    		 orderedItems = delegator.findList("OrderHeaderItemProductShipmentAndFacility", condition, UtilMisc.toSet("estimatedDeliveryDate","quantity","productId","originFacilityId","shipmentId", "categoryTypeEnum"), null, null, false);
    	 }catch(GenericEntityException e){
    		 Debug.logError(e, e.toString(), module);
             return ServiceUtil.returnError(e.toString());
    	 }
    	 Map totalProductQuant = FastMap.newInstance();
    	 List daywiseSales = FastList.newInstance();
    	 Map daySale = FastMap.newInstance();
    	 for(int k =0;k<intervalDays;k++){
    		
    		List condList = FastList.newInstance(); 
 			Timestamp supplyDate = UtilDateTime.addDaysToTimestamp(fromDate, k);
 			Timestamp dayStart = UtilDateTime.getDayStart(supplyDate);
 			Timestamp dayEnd = UtilDateTime.getDayEnd(supplyDate); 
 			List dayWiseShipmentList = ByProductNetworkServices.getByProdShipmentIds(delegator, dayStart, dayEnd);
 			
 			List<GenericValue> daywiseParlourOrders = EntityUtil.filterByCondition(orderedItems, EntityCondition.makeCondition("shipmentId", EntityOperator.IN, dayWiseShipmentList));
 			List tempDayPartyList = FastList.newInstance();
 			tempDayPartyList = EntityUtil.getFieldListFromEntityList(daywiseParlourOrders, "originFacilityId", true);
 			List dayPartyList = FastList.newInstance();
 			for(int j=0;j<tempDayPartyList.size();j++){
 				String booth = (String)tempDayPartyList.get(j);
 				booth = booth.toUpperCase();
 				if(!dayPartyList.contains(booth)){
 					dayPartyList.add(booth);
 				}
 			}
 			Map partySale = FastMap.newInstance();
 			String boothId = "";
 			if(UtilValidate.isNotEmpty(dayPartyList)){
 				for(int i=0;i<dayPartyList.size();i++){
 					boothId = (String)dayPartyList.get(i);
 					Map productQuant = FastMap.newInstance();
 					List daywiseBoothwiseSale = EntityUtil.filterByCondition(daywiseParlourOrders, EntityCondition.makeCondition(EntityFunction.UPPER_FIELD("originFacilityId"), EntityOperator.EQUALS, EntityFunction.UPPER(((String)boothId).toUpperCase())));
 					for(int j=0 ; j<daywiseBoothwiseSale.size();j++){
 						GenericValue eachOrderItem = (GenericValue)daywiseBoothwiseSale.get(j);
 						String productId = eachOrderItem.getString("productId");
 						BigDecimal quantity = eachOrderItem.getBigDecimal("quantity");
 						if(productQuant.containsKey(productId)){
 							BigDecimal tempQty = (BigDecimal)productQuant.get(productId);
 							BigDecimal totalQty = tempQty.add(quantity);
 							productQuant.put(productId, totalQty);
 						}else{
 							productQuant.put(productId,quantity);
 						}
 						if(totalProductQuant.containsKey(productId)){
 							BigDecimal tempTotQty = (BigDecimal)totalProductQuant.get(productId);
 							BigDecimal totalQuant = tempTotQty.add(quantity);
 							totalProductQuant.put(productId, totalQuant);
 						}
 						else{
 							totalProductQuant.put(productId, quantity);
 						}
 					}
 					partySale.put(boothId, productQuant);
 				}
 			}
 			daySale.put(dayStart, partySale);
 			daywiseSales.add(daySale);
 		 }
    	 result.put("totalSales", totalProductQuant);
    	 result.put("datewiseSales", daywiseSales);
		 return result;
	 }
	 
	 public static Map getDayWiseTotalSales(DispatchContext dctx, Timestamp fromDate, Timestamp thruDate, String salesChannel, List productList)  {
		 
		 Delegator delegator = dctx.getDelegator();
		 LocalDispatcher dispatcher = dctx.getDispatcher();
		     
		 Map result = FastMap.newInstance();
		 int intervalDays = (UtilDateTime.getIntervalInDays(fromDate, thruDate)+1);
    	 List orderedItems = FastList.newInstance();
    	 List conditionList = FastList.newInstance();
    	 conditionList.add(EntityCondition.makeCondition("orderStatusId", EntityOperator.NOT_EQUAL , "ORDER_CANCELLED"));
    	 conditionList.add(EntityCondition.makeCondition("orderStatusId", EntityOperator.NOT_EQUAL ,"ORDER_REJECTED"));
    	 conditionList.add(EntityCondition.makeCondition("salesChannelEnumId", EntityOperator.EQUALS, "BYPROD_SALES_CHANNEL"));
    	 if(UtilValidate.isNotEmpty(productList)){
    		 conditionList.add(EntityCondition.makeCondition("productId", EntityOperator.IN, productList));
    	 }
    	 conditionList.add(EntityCondition.makeCondition("estimatedDeliveryDate", EntityOperator.GREATER_THAN_EQUAL_TO ,fromDate));
    	 conditionList.add(EntityCondition.makeCondition("estimatedDeliveryDate", EntityOperator.LESS_THAN_EQUAL_TO ,thruDate));
    	 EntityCondition condition = EntityCondition.makeCondition(conditionList,EntityOperator.AND);
    	 try{
    		 orderedItems = delegator.findList("OrderHeaderItemProductShipmentAndFacility", condition, UtilMisc.toSet("estimatedDeliveryDate","quantity","productId","originFacilityId","ownerPartyId"), null, null, false);
    	 }catch(GenericEntityException e){
    		 Debug.logError(e, e.toString(), module);
             return ServiceUtil.returnError(e.toString());
    	 }
    	 List shipmentList = ByProductNetworkServices.getByProdShipmentIds(delegator, fromDate, thruDate);
    	// List shipmentList = ByProductNetworkServices.getByProdShipmentIdsByType(delegator, fromDate, thruDate, "BYPRODUCTS");
    	 conditionList.clear(); 
 		 conditionList.add(EntityCondition.makeCondition("shipmentId",  EntityOperator.IN, shipmentList));
 		 conditionList.add(EntityCondition.makeCondition("isCancelled",  EntityOperator.EQUALS, null));
 		 if(UtilValidate.isNotEmpty(productList)){
   		    conditionList.add(EntityCondition.makeCondition("productId", EntityOperator.IN, productList));
 		 }
 		 conditionList.add(EntityCondition.makeCondition("productSubscriptionTypeId",  EntityOperator.EQUALS, "CASH_BYPROD"));
 		 EntityCondition shipReceiptCond = EntityCondition.makeCondition(conditionList,EntityOperator.AND);
 		 List<GenericValue> shipReceiptList = FastList.newInstance();
    	 try{
    		 shipReceiptList = delegator.findList("ShipmentReceiptAndItem", shipReceiptCond, UtilMisc.toSet("facilityId", "productId", "datetimeReceived", "quantityAccepted"), UtilMisc.toList("productId"), null, false);
    	 }catch(GenericEntityException e){
    		 Debug.logError(e, e.toString(), module);
             return ServiceUtil.returnError(e.toString());
    	 }
    	 
    	 /*==============GET PRICES BASED ON PARTY CLASSIFICATION=============*/
	    	Map classificationMap = FastMap.newInstance();
	    	
	    	List<GenericValue> partyClassificationList = null;
	    	try{
	    		partyClassificationList = delegator.findList("PartyClassificationGroup", EntityCondition.makeCondition("partyClassificationTypeId", EntityOperator.EQUALS,"PM_RC"),UtilMisc.toSet("partyClassificationGroupId"), null, null, false);
	    	}catch (GenericEntityException e) {
	    		Debug.logError("Unable to get records from PartyClassificationGroup"+e, module);
	    		return ServiceUtil.returnError("Unable to get records from PartyClassificationGroup"); 
			}
	    	List partyClassifications = EntityUtil.getFieldListFromEntityList(partyClassificationList, "partyClassificationGroupId", true);
	    	for(int i=0; i<partyClassifications.size(); i++){
	    		Map productsPrice = (Map) ByProductReportServices.getByProductPricesForPartyClassification(dctx, UtilMisc.toMap("partyClassificationId", partyClassifications.get(i))).get("productsPrice");
				classificationMap.put(partyClassifications.get(i), productsPrice);
	    	}
	    /*==============END=============*/
    	 Map dayWiseSale = FastMap.newInstance();
    	 
    	 Map totalSalesMap = FastMap.newInstance();
    	 
    	 BigDecimal totalBasicPrice = BigDecimal.ZERO;
  		 BigDecimal grandTotalPrice = BigDecimal.ZERO;
  		 BigDecimal totalVatAmt = BigDecimal.ZERO;
  		 BigDecimal totalExDuty = BigDecimal.ZERO;
  		 BigDecimal totalEdCess = BigDecimal.ZERO;
  		 BigDecimal totalHigherSecCess = BigDecimal.ZERO;
  		 BigDecimal grandTotalExcise = BigDecimal.ZERO;
    	 
    	 for(int k =0; k<intervalDays; k++){
    		
 			Timestamp supplyDate = UtilDateTime.addDaysToTimestamp(fromDate, k);
 			Timestamp dayStart = UtilDateTime.getDayStart(supplyDate);
 			Timestamp dayEnd = UtilDateTime.getDayEnd(supplyDate); 
 			
 			List<GenericValue> daywiseParlourOrders = EntityUtil.filterByCondition(orderedItems, EntityCondition.makeCondition(EntityCondition.makeCondition("estimatedDeliveryDate", EntityOperator.GREATER_THAN_EQUAL_TO, dayStart),EntityOperator.AND,
 	    			 EntityCondition.makeCondition("estimatedDeliveryDate", EntityOperator.LESS_THAN_EQUAL_TO, dayEnd)));
 			
 			
 			List<GenericValue> daywiseShipmentReceipts = EntityUtil.filterByCondition(shipReceiptList, EntityCondition.makeCondition(EntityCondition.makeCondition("datetimeReceived", EntityOperator.GREATER_THAN_EQUAL_TO, dayStart),EntityOperator.AND,
	    			 EntityCondition.makeCondition("datetimeReceived", EntityOperator.LESS_THAN_EQUAL_TO, dayEnd)));
 			
 			Map salesMap = FastMap.newInstance();
 			
 			BigDecimal basicPrice = BigDecimal.ZERO;
     		BigDecimal totalPrice = BigDecimal.ZERO;
     		     		
     		BigDecimal exDutyPrecent = BigDecimal.ZERO;
     		BigDecimal edCessPrecent = BigDecimal.ZERO;
     		BigDecimal higherSecCessPercent = BigDecimal.ZERO;
     		
     		for(int i=0; i<daywiseShipmentReceipts.size(); i++){
 				
 				GenericValue eachReceiptItem = (GenericValue)daywiseShipmentReceipts.get(i);
				
 				String productId = eachReceiptItem.getString("productId");
				BigDecimal quantity = eachReceiptItem.getBigDecimal("quantityAccepted");
				//String ownerPartyId = eachOrderItem.getString("ownerPartyId");
				
	     		Map priceMap = (Map) classificationMap.get("PM_RC_P");
	     		Map prodPriceMap = (Map)priceMap.get(productId);
	     		
	     		BigDecimal basicValue = ((BigDecimal)prodPriceMap.get("basicPrice")).multiply(quantity);
	     		BigDecimal totalValue = ((BigDecimal)prodPriceMap.get("totalAmount")).multiply(quantity);
	     			     		
	     		exDutyPrecent = (BigDecimal)prodPriceMap.get("bedPercentage");
	     		edCessPrecent = (BigDecimal)prodPriceMap.get("bedCessPercent");
	     		higherSecCessPercent = (BigDecimal)prodPriceMap.get("bedsecPercent");
	     		
	     		basicPrice = basicPrice.add(basicValue);
	     		totalPrice = totalPrice.add(totalValue);
	     		
	     		     		
	     		totalBasicPrice = totalBasicPrice.add(basicValue);
	     		grandTotalPrice = grandTotalPrice.add(totalValue);

 			}
     		
 			for(int i=0; i<daywiseParlourOrders.size(); i++){
 				
 				GenericValue eachOrderItem = (GenericValue)daywiseParlourOrders.get(i);
				
 				String productId = eachOrderItem.getString("productId");
				BigDecimal quantity = eachOrderItem.getBigDecimal("quantity");
				String ownerPartyId = eachOrderItem.getString("ownerPartyId");
				
				String partyClassificationTypeId = null;
	     		List<GenericValue> partyClassification = null;
	     		try{
	     			List<GenericValue> partyClassificationGroup = delegator.findList("PartyClassification", EntityCondition.makeCondition("partyId", EntityOperator.EQUALS, ownerPartyId), null, null, null, false);
    				if(UtilValidate.isNotEmpty(partyClassificationGroup)){
    					partyClassificationTypeId = (String) EntityUtil.getFirst(partyClassificationGroup).get("partyClassificationGroupId");
    				}
	     		}catch(GenericEntityException e){
	     			Debug.logError("No partyRole found for given partyId:"+ ownerPartyId, module);
	     			return ServiceUtil.returnError("No partyRole found for given partyId");
	     		}
				
	     		Map priceMap = (Map) classificationMap.get(partyClassificationTypeId);
	     		Map prodPriceMap = (Map)priceMap.get(productId);
	     		
	     		BigDecimal basicValue = ((BigDecimal)prodPriceMap.get("basicPrice")).multiply(quantity);
	     		BigDecimal totalValue = ((BigDecimal)prodPriceMap.get("totalAmount")).multiply(quantity);
	     		
	     		exDutyPrecent = (BigDecimal)prodPriceMap.get("bedPercentage");
	     		edCessPrecent = (BigDecimal)prodPriceMap.get("bedCessPercent");
	     		higherSecCessPercent = (BigDecimal)prodPriceMap.get("bedsecPercent");
	     		
	     		basicPrice = basicPrice.add(basicValue);
	     		totalPrice = totalPrice.add(totalValue);
	     		
	     		totalBasicPrice = totalBasicPrice.add(basicValue);
	     		grandTotalPrice = grandTotalPrice.add(totalValue);

 			}
 			
 			salesMap.put("basicPrice", basicPrice);
 			salesMap.put("totalPrice", totalPrice);
 			
 			salesMap.put("exDutyPrecent", exDutyPrecent);
 			salesMap.put("edCessPrecent", edCessPrecent);
 			salesMap.put("higherSecCessPer", higherSecCessPercent);
 			
 			Map tempDayWiseSales = FastMap.newInstance();
 			tempDayWiseSales.putAll(salesMap);
 			
 			String dayStartStr = dayStart.toString();
 			
 			if (dayStartStr.contains("00:00:00.0")) {
 				String[] dayStartStrSplit = dayStartStr.split("00:00:00.0");
 				dayStartStr = dayStartStrSplit[0];
 			}
 			dayWiseSale.put(dayStartStr, tempDayWiseSales);
 		 }
    	 grandTotalExcise = (totalExDuty.add(totalEdCess)).add(totalHigherSecCess);
    	 
    	 totalSalesMap.put("basicPrice", totalBasicPrice);
    	 totalSalesMap.put("totalPrice", grandTotalPrice);
    	 
    	 Map tempTotalSales = FastMap.newInstance();
    	 tempTotalSales.putAll(totalSalesMap);
    	 
    	 dayWiseSale.put("totalSales", tempTotalSales);
    	 
    	 result.put("dayWiseSale", dayWiseSale);
		 return result;
	 }
	 
	 
	 public static Map getByProductParlourDespatch(DispatchContext dctx, Timestamp fromDate, Timestamp thruDate)  {
		 
		 Delegator delegator = dctx.getDelegator();
		 LocalDispatcher dispatcher = dctx.getDispatcher();
		     
		 Map result = FastMap.newInstance();
		 int intervalDays = (UtilDateTime.getIntervalInDays(fromDate, thruDate)+1);
    	 //List orderedItems = FastList.newInstance();
    	 
    	 List shipmentList = ByProductNetworkServices.getByProdShipmentIdsByType(delegator, fromDate, thruDate, "BYPRODUCTS");
    	 List conditionList = FastList.newInstance(); 
 		 conditionList.add(EntityCondition.makeCondition("shipmentId",  EntityOperator.IN, shipmentList));
 		 conditionList.add(EntityCondition.makeCondition("isCancelled",  EntityOperator.EQUALS, null));
 		 conditionList.add(EntityCondition.makeCondition(EntityCondition.makeCondition("productSubscriptionTypeId", EntityOperator.EQUALS, null), EntityOperator.OR, EntityCondition.makeCondition("productSubscriptionTypeId", EntityOperator.NOT_IN, UtilMisc.toList("REPLACEMENT_BYPROD","BYPROD_GIFT"))));
 		 EntityCondition shipReceiptCond = EntityCondition.makeCondition(conditionList,EntityOperator.AND);
 		 List<GenericValue> shipReceiptList = FastList.newInstance();
    	 try{
    		 shipReceiptList = delegator.findList("ShipmentReceiptAndItem", shipReceiptCond, UtilMisc.toSet("facilityId", "productId", "datetimeReceived", "quantityAccepted"), UtilMisc.toList("productId"), null, false);
    	 }catch(GenericEntityException e){
    		 Debug.logError(e, e.toString(), module);
             return ServiceUtil.returnError(e.toString());
    	 }
    	 Map totalProductQuant = FastMap.newInstance();
    	 List daywiseDespatch = FastList.newInstance();
    	 Map dayDespatch = FastMap.newInstance();
    	 for(int k =0;k<intervalDays;k++){
    		
    		List condList = FastList.newInstance(); 
 			Timestamp supplyDate = UtilDateTime.addDaysToTimestamp(fromDate, k);
 			Timestamp dayStart = UtilDateTime.getDayStart(supplyDate);
 			Timestamp dayEnd = UtilDateTime.getDayEnd(supplyDate); 
 			List<GenericValue> daywiseParlourOrders = EntityUtil.filterByCondition(shipReceiptList, EntityCondition.makeCondition(EntityCondition.makeCondition("datetimeReceived", EntityOperator.GREATER_THAN_EQUAL_TO, dayStart),EntityOperator.AND,
 	    			 EntityCondition.makeCondition("datetimeReceived", EntityOperator.LESS_THAN_EQUAL_TO, dayEnd)));
 			List dayPartyList = FastList.newInstance();
 			List tempDayPartyList = FastList.newInstance();
 			tempDayPartyList = EntityUtil.getFieldListFromEntityList(daywiseParlourOrders, "facilityId", true);
 			for(int j=0;j<tempDayPartyList.size();j++){
 				String booth = (String)tempDayPartyList.get(j);
 				booth = booth.toUpperCase();
 				if(!dayPartyList.contains(booth)){
 					dayPartyList.add(booth);
 				}
 			}
 			Map partySale = FastMap.newInstance();
 			String boothId = "";
 			if(UtilValidate.isNotEmpty(dayPartyList)){
 				for(int i=0;i<dayPartyList.size();i++){
 		 			Map productQuant = FastMap.newInstance();
 					boothId = (String)dayPartyList.get(i);
 					List daywiseBoothwiseSale = EntityUtil.filterByCondition(daywiseParlourOrders, EntityCondition.makeCondition(EntityFunction.UPPER_FIELD("facilityId"), EntityOperator.EQUALS, EntityFunction.UPPER(((String)boothId).toUpperCase())));
 					for(int j=0 ; j<daywiseBoothwiseSale.size();j++){
 						GenericValue eachOrderItem = (GenericValue)daywiseBoothwiseSale.get(j);
 						String productId = eachOrderItem.getString("productId");
 						BigDecimal quantity = eachOrderItem.getBigDecimal("quantityAccepted");
 						if(productQuant.containsKey(productId)){
 							BigDecimal tempQty = (BigDecimal)productQuant.get(productId);
 							BigDecimal totalQty = tempQty.add(quantity);
 							productQuant.put(productId, totalQty);
 						}else{
 							productQuant.put(productId,quantity);
 						}
 						if(totalProductQuant.containsKey(productId)){
 							BigDecimal tempTotQty = (BigDecimal)totalProductQuant.get(productId);
 							BigDecimal totalQuant = tempTotQty.add(quantity);
 							totalProductQuant.put(productId, totalQuant);
 						}
 						else{
 							totalProductQuant.put(productId, quantity);
 						}
 					}
 					partySale.put(boothId, productQuant);
 				}
 				
 			}
 			dayDespatch.put(dayStart, partySale);
 			daywiseDespatch.add(dayDespatch);
 		 }
    	 result.put("totalDespatch", totalProductQuant);
    	 result.put("datewiseDespatch", daywiseDespatch);
		 return result;
	 }
	 
	 public static Map getByProductSubscriptionId(Delegator delegator, String facilityId)  {
		 
		 Map result = FastMap.newInstance();
		 String subscriptionId = "";
    	 List<GenericValue> subscriptionList =FastList.newInstance();
    	 try{
    		 List condList =FastList.newInstance();
    		 condList.add(EntityCondition.makeCondition("subscriptionTypeId", EntityOperator.EQUALS, "BYPRODUCTS"));
    		 condList.add(EntityCondition.makeCondition("facilityId", EntityOperator.EQUALS, facilityId));
    		 EntityCondition condition = EntityCondition.makeCondition(condList, EntityOperator.AND);      
    		 subscriptionList = delegator.findList("Subscription", condition, null, null, null, false);
    		 subscriptionList = EntityUtil.filterByDate(subscriptionList, UtilDateTime.nowTimestamp());	 
    		 if(UtilValidate.isNotEmpty(subscriptionList)){
    			 GenericValue subscription = EntityUtil.getFirst(subscriptionList);
    			 subscriptionId = subscription.getString("subscriptionId");
    		 }
    	 }catch (GenericEntityException e) {
			// TODO: handle exception
    		Debug.logError(e, module);
    	 }
    	 result.put("subscriptionId", subscriptionId);
		 return result;
	 }
	 
	 public static List getByProdShipmentIds(Delegator delegator,Timestamp fromDate,Timestamp thruDate){
		 List shipments = ByProductNetworkServices.getByProdShipmentIds(delegator, fromDate, thruDate, null);
		 return shipments;
	 }
	 
	 public static List getByProdShipmentIds(Delegator delegator,Timestamp fromDate,Timestamp thruDate,List routeIds){
			
			List conditionList= FastList.newInstance(); 
			List shipmentList =FastList.newInstance();
			List shipments = FastList.newInstance();
			Timestamp dayBegin = UtilDateTime.nowTimestamp();
			Timestamp dayEnd = UtilDateTime.getDayEnd(thruDate);
			try{
				List<GenericValue> shipmentTypeIds = delegator.findList("ShipmentType",EntityCondition.makeCondition("parentTypeId", EntityOperator.IN ,UtilMisc.toList("LMS_SHIPMENT","LMS_SHIPMENT_SUPPL")) , null , null, null, false);
				conditionList.add(EntityCondition.makeCondition("shipmentTypeId", EntityOperator.IN , EntityUtil.getFieldListFromEntityList(shipmentTypeIds, "shipmentTypeId", true)));
			}catch (Exception e) {
				Debug.logError(e, "Exception while getting shipment ids ", module);		   
			}
			
			conditionList.add(EntityCondition.makeCondition("statusId", EntityOperator.EQUALS , "GENERATED"));
			if(UtilValidate.isNotEmpty(routeIds)){
				conditionList.add(EntityCondition.makeCondition("routeId", EntityOperator.IN , routeIds));
			}
			if(!UtilValidate.isEmpty(fromDate)){
				dayBegin = UtilDateTime.getDayStart(fromDate);
				conditionList.add(EntityCondition.makeCondition("estimatedShipDate", EntityOperator.GREATER_THAN_EQUAL_TO ,dayBegin));
			}
			
			conditionList.add(EntityCondition.makeCondition("estimatedShipDate", EntityOperator.LESS_THAN_EQUAL_TO ,dayEnd));
			EntityCondition condition = EntityCondition.makeCondition(conditionList,EntityOperator.AND);	
			try {
				shipmentList =delegator.findList("Shipment", condition, null , null, null, false);
			}catch (Exception e) {
				Debug.logError(e, "Exception while getting shipment ids ", module);		   
			}
			if(!UtilValidate.isEmpty(shipmentList)){
				shipments.addAll(EntityUtil.getFieldListFromEntityList(shipmentList, "shipmentId", false));
			}		
			
			return shipments;
	}
	
	public static Map<String, Object> getByProductActiveFacilities(Delegator delegator, Timestamp effectiveDate){
		    
		Map<String, Object> result = FastMap.newInstance(); 
		List<String> boothIds = FastList.newInstance(); 
	    List<GenericValue> booths = null;
	    	
	    if(UtilValidate.isEmpty(effectiveDate)){
	    	effectiveDate = UtilDateTime.nowTimestamp();
	    }
		result = ByProductServices.getAllByproductBooths(delegator, effectiveDate);
		List excludeList = UtilMisc.toList("REPLACEMENT_BYPROD","BYPROD_GIFT","BYPRODUCTS","BYPROD_SO","SP_SALES");
		if(UtilValidate.isNotEmpty(result.get("boothsList"))){
			booths = (List)result.get("boothsList");
			booths = EntityUtil.filterByCondition(booths, EntityCondition.makeCondition("categoryTypeEnum", EntityOperator.NOT_IN, excludeList));
			booths = EntityUtil.filterByCondition(booths, EntityCondition.makeCondition("byProdRouteId", EntityOperator.NOT_EQUAL, null));
			boothIds = EntityUtil.getFieldListFromEntityList(booths, "facilityId", true);
		}
		result.put("boothsList", booths);
	    result.put("boothsIdsList", boothIds);
		return result;
	}
	 
	 public static List getByProdShipmentIdsByType(Delegator delegator,Timestamp fromDate,Timestamp thruDate ,String shipmentTypeId){
		 List shipments = ByProductNetworkServices.getByProdShipmentIdsByType(delegator, fromDate, thruDate, shipmentTypeId, null);
		 return shipments;
	 }
	 public static List getByProdShipmentIdsByType(Delegator delegator,Timestamp fromDate,Timestamp thruDate ,String shipmentTypeId, List routeIds){
			
			List conditionList= FastList.newInstance(); 
			List shipmentList =FastList.newInstance();
			List shipments = FastList.newInstance();
			Timestamp dayBegin = UtilDateTime.nowTimestamp();
			Timestamp dayEnd = UtilDateTime.getDayEnd(thruDate);
			conditionList.add(EntityCondition.makeCondition("shipmentTypeId", EntityOperator.EQUALS,shipmentTypeId));
			conditionList.add(EntityCondition.makeCondition("statusId", EntityOperator.EQUALS , "GENERATED"));
			if(UtilValidate.isNotEmpty(routeIds)){
				conditionList.add(EntityCondition.makeCondition("routeId", EntityOperator.IN , routeIds));
			}
			if(!UtilValidate.isEmpty(fromDate)){
				dayBegin = UtilDateTime.getDayStart(fromDate);
				conditionList.add(EntityCondition.makeCondition("estimatedShipDate", EntityOperator.GREATER_THAN_EQUAL_TO ,dayBegin));
			}
			
			conditionList.add(EntityCondition.makeCondition("estimatedShipDate", EntityOperator.LESS_THAN_EQUAL_TO ,dayEnd));
			EntityCondition condition = EntityCondition.makeCondition(conditionList,EntityOperator.AND);	
			try {
				shipmentList =delegator.findList("Shipment", condition, null , null, null, false);
			}catch (Exception e) {
				Debug.logError(e, "Exception while getting shipment ids ", module);		   
			}
			if(!UtilValidate.isEmpty(shipmentList)){
				shipments.addAll(EntityUtil.getFieldListFromEntityList(shipmentList, "shipmentId", false));
			}		
			
			return shipments;
		}
	 
	 public static Map<String, Object> getFacilityFieldStaff(DispatchContext dctx, Map<String, ? extends  Object> context ){
		    
			Map<String, Object> result = FastMap.newInstance();
			List conditionList= FastList.newInstance(); 
			List<String> boothIds = FastList.newInstance(); 
		    List<GenericValue> facilityPartyList = null;
		    Timestamp saleDate = UtilDateTime.nowTimestamp();
		    Delegator delegator = dctx.getDelegator();
		    Map<String, String> facilityFieldStaffMap = FastMap.newInstance();
		    Map<String, List> fieldStaffAndFacility = FastMap.newInstance();
		    if(UtilValidate.isNotEmpty(context.get("saleDate"))){
		    	saleDate = (Timestamp)context.get("saleDate");
		    }
		    
		    conditionList.add(EntityCondition.makeCondition("roleTypeId", EntityOperator.EQUALS,"FIELD_STAFF"));
		    EntityCondition condition = EntityCondition.makeCondition(conditionList,EntityOperator.AND);	
		    try {
		    	facilityPartyList =delegator.findList("FacilityParty", condition, null , null, null, false);
		    	facilityPartyList = EntityUtil.filterByDate(facilityPartyList, saleDate);
		    	for(GenericValue facilityParty : facilityPartyList){
		    		facilityFieldStaffMap.put(facilityParty.getString("facilityId"), facilityParty.getString("partyId"));
		    		if(UtilValidate.isNotEmpty(fieldStaffAndFacility.get(facilityParty.getString("partyId")))){
		    			List facilityList = fieldStaffAndFacility.get(facilityParty.getString("partyId"));
		    			facilityList.add(facilityParty.getString("facilityId"));
		    			fieldStaffAndFacility.put(facilityParty.getString("partyId"), facilityList);
		    			
		    		}else{
		    			fieldStaffAndFacility.put(facilityParty.getString("partyId"), UtilMisc.toList(facilityParty.getString("facilityId")));
		    		}
		    	}
		    	
			}catch (Exception e) {
				Debug.logError(e, "Exception while getting FaclityParty ", module);		   
			}
			result.put("facilityFieldStaffMap", facilityFieldStaffMap);
			result.put("fieldStaffAndFacility", fieldStaffAndFacility);
			return result;
	}
}
	
	